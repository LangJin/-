# -*- coding:utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://lot.hpwbt666.com/bettingHall/betScreen?lotId=5&pid=507")
elments = driver.find_elements_by_css_selector("span.content")
# print(len(elments))
# for i in range(len(elments)):
#     elments[i].click()
# for elment in elments:
#     # print(elment)
#     elment.click()
elments[2].click()
elments = driver.find_elements_by_css_selector("span#smalllabel_0_0.method-tab-front")
elments[2].click()
time.sleep(1)
elments = driver.find_elements_by_css_selector("div#wei_1_0")
# elments = driver.find_elements_by_name("lt_place_0")
for el in elments:
    # print(el.text)
    # time.sleep(0.1)
    el.click()
elment = driver.find_element_by_xpath("//*[@id=\"mySlider\"]/span/div/div/div[2]/div")
elment1 = driver.find_element_by_xpath("//*[@id=\"lt_sel_insert\"]")
ActionChains(driver).drag_and_drop(elment, elment1).perform()
time.sleep(2)
driver.quit()
# import unittest


# class Testdemo(unittest.TestCase):

#     def setUp(self):
#         print("开始")

#     def tearDown(self):
#         print("结束")

#     def test_demo_01(self):
#         print("第一个用例")

#     def test_demo_02(self):
#         print("第二个用例")


# if __name__ == '__main__':
#     unittest.main()
