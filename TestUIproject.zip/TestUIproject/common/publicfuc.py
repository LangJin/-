# -*- coding:utf-8 -*-
from common import gettoken
from config import config


def createjs():
    optCode = gettoken.GetWriteCode()
    username = config.username
    data = gettoken.userlogin(username, optCode)
    token = data["token"]
    user = data["user"]["userName"]
    balance = data["user"]["balance"]
    userDisabled = data["user"]["status"]
    isTest = data["user"]["isTest"]
    userValid = data["user"]["status"]
    userType = data["user"]["userType"]
    oid = data["user"]["oid"]
    # userId = ????
    time1 = 1
    script = "localStorage.setItem('token', '%s');\
        localStorage.setItem('user', '%s');\
        localStorage.setItem('balance', %s);\
        localStorage.setItem('userDisabled', %s);\
        localStorage.setItem('isTest', %s);\
        localStorage.setItem('userValid', %s);\
        localStorage.setItem('userType', %s);\
        localStorage.setItem('oid', %s);\
        localStorage.setItem('time', %s);" % (token, user, balance,
                                              userDisabled, isTest, userValid,
                                              userType, oid, time1)
    return script
