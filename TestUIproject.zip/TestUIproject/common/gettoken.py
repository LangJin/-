from config import config
from common.log import Log
import pytesseract
from PIL import Image
import requests
import json

file_home = config.img_path  # 更改为你本地路径，用来存验证码的图片的
hurl = config.login_url
logger = Log()


def GetWriteCode():
    '''
    调用接口请求验证码，保存到本地，识别验证，检查识别的验证码对不对。
    '''
    filename = 'getCaptcha.jpg'  # 定义的验证码的名字
    url = hurl + "/file/getCaptcha1"  # 获取验证码的接口地址
    headers = {  # 接口所需参数
        'content-type': "application/json;charset=utf-8",
        'fr': "6",
        'http-cust-oid': "988"
        }
    hcode = 'b0a3dc8f-c0d4-475d-9c1a-eb41370bf4bf'  # 获取验证码需要的参数
    try:
        # print(hcode)
        querystring = {"w": "100", "h": "38", "code": hcode}  # 传入对于的headers数据
        response = requests.request("GET", url, headers=headers, params=querystring)  # 发送请求
        # print(response.text)
        img = response.content  # 二进制保存验证码
        with open(file_home+filename, 'wb') as f:  # 保存到上面定义的路径
            f.write(img)
            # print("OK")
        image = Image.open(file_home+filename)  # 读取验证码图片
        optCode = pytesseract.image_to_string(image)  # 开始识别验证码
        assert len(optCode) == 4  # 判断是不是四位数
        logger.info("SUCCESS    当前的验证码是%s     ==========" % optCode)
        # print(optCode)  # 打印出验证码
        # print("-----------------------------")
        return optCode
    except:
        return GetWriteCode()  # 递归


def userlogin(username, optCode):
    url = hurl + "/login"  # 获取验证码的接口地址
    data = {
        "userName": username,
        "passWord": "a123456",
        "code": "b0a3dc8f-c0d4-475d-9c1a-eb41370bf4bf",
        "optCode": optCode,
        "otp": 123456
    }
    headers = {  # 接口所需参数
        'content-type': "application/json;charset=utf-8",
        'fr': "6",
        'http-cust-oid': "988"
        }
    r = requests.post(url, data=json.dumps(data), headers=headers)
    hjson = json.loads(r.text)  # 获取并处理返回的json数据
    herror = "error"
    if herror in hjson:
        logger.error("FAIL    登陆失败，退出程序！   ==========")
        # print("登陆失败，退出程序！")
    else:
        hcode = str(hjson['code'])
        logger.info("SUCCESS     请求返回状态为：%s   =======" % hcode)
        # print('请求返回状态为：' + hcode)
        if hcode == "200":
            hdata = hjson['data']
            logger.info("SUCCESS    登陆成功！！！！！ ======")
            return hdata
        else:
            logger.error("FAIL    登陆失败，退出程序！%s   ==========" % hjson['msg'])
            # print('请求返回消息为：' + hjson['msg'])
            # print('登陆失败，程序退出')
