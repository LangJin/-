# -*- coding:utf-8 -*-

import unittest
from common import pyselenium
from common import publicfuc
from config import config
from common.log import Log


class MyTest(unittest.TestCase):
    """
    The base class is for all testcase.
    """
    def setUp(self):
        self.logger = Log()
        self.logger.info('############################### START ###############################')
        self.dr = pyselenium.PySelenium(config.browser)
        self.dr.max_window()

    def tearDown(self):
        self.dr.quit()
        self.logger.info('###############################  End  ###############################')


class MylotTest(unittest.TestCase):
    """
    用于购彩大厅的用例，把进入购彩大厅页面和登陆写成初始化
    """
    def setUp(self):
        self.logger = Log()
        self.logger.info('############################### START ###############################')
        self.dr = pyselenium.PySelenium(config.browser)
        self.dr.max_window()
        self.dr.open(config.bettingHall_url)
        script = publicfuc.createjs()
        self.dr.js(script)
        self.dr.F5()

    def tearDown(self):
        self.dr.quit()
        self.logger.info('###############################  End  ###############################')
