# -*- coding:utf-8 -*-
from time import sleep
from common import mytest
from pages import bettingHallhome


class Testcqsscplay(mytest.MylotTest):
    """重庆时时彩测试"""

    def test_csqqc_wxzxfs(self):
        """五星直选复式"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(0, 0)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_sxzxfs(self):
        """四星直选复式"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(1, 0)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszxfs(self):
        """后三直选复式"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 0)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszxhz(self):
        """后三直选和值"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 2)
        sleep(1)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszxkd(self):
        """后三直选跨度"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 3)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hshszh(self):
        """后三后三组合"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 4)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszsfs(self):
        """后三组三复式"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 5)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszlfs(self):
        """后三组六复式"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 7)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszuxhz(self):
        """后三组选和值"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 10)
        sleep(1)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hszuxbd(self):
        """后三组选包胆"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 11)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hshzws(self):
        """后三和值尾数"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 12)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)

    def test_csqqc_hstsh(self):
        """后三特殊号"""
        driver = bettingHallhome.bettingHallPage(self.dr)
        driver.opne_cqssc_url()
        lotname = driver.return_lotname()
        self.assertEqual('重庆时时彩', lotname)
        driver.click_play(2, 13)
        driver.select_num()
        driver.move_elment()
        driver.add_order()
        driver.submit_order()
        sleep(1)
        text = driver.asserttext()
        self.assertEqual('购买成功，欢迎继续下注', text)
