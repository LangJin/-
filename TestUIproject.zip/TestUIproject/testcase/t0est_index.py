# -*- coding:utf-8 -*-
from time import sleep
from common import mytest
from pages import c132IndexPage


class Test132Index(mytest.MyTest):
    """132彩票首页测试"""

    def test_title(self):
        """获取首页title"""
        indexpage = c132IndexPage.C132IndexPage(self.dr)
        indexpage.into_132_page()
        title = indexpage.get_index_title()
        print(title)
        self.assertEqual('s342', title)
        sleep(1)

    def test_00_demo(self):
            """ 此用例成功 """
            for i in range(5):
                with self.subTest(data=i):  # 注意这里subTest的用法
                    self.assertEqual(1+2, 3)
