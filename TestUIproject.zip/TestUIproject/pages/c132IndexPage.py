# -*- coding:utf-8 -*-
from common import basepage


class C132IndexPage(basepage.Page):

    def into_132_page(self):
        """打开132首页"""
        self.dr.open('http://lot.hpwbt666.com/home')

    def get_index_title(self):
        '''获取title'''
        return self.dr.get_title()
