# -*- coding:utf-8 -*-
from common import basepage


class bettingHallPage(basepage.Page):
    '''重庆时时彩'''
    def opne_cqssc_url(self):
        '''打开重庆时时彩'''
        self.dr.click('xpath->/html/body/div[1]/div/div[2]/div[2]/div/div/div/div/div[1]/div/div/div[2]/div[3]/a/button')

    def return_lotname(self):
        '''打开重庆时时彩'''
        return self.dr.get_text('name->page_name')

    def F5(self):
        '''刷新页面'''
        self.dr.F5()

    def click_play(self, bignum, smallnum):
        '''选择玩法'''
        self.dr.selcet_clicks('css->span.content', bignum)
        self.dr.selcet_clicks('css->span#smalllabel_0_0.method-tab-front', smallnum)

    def select_num(self):
        '''选择下注号码'''
        self.dr.clicks('css->div#wei_1_0')

    def add_order(self):
        '''添加注单'''
        self.dr.click('css->div#lt_sel_insert.g_submit')

    def submit_order(self):
        '''提交订单'''
        self.dr.click('css->div#lt_buy.g_submit')
        self.dr.click('css->button.ivu-btn.ivu-btn-primary.ivu-btn-large')

    def asserttext(self):
        '''判断下注是否成功'''
        return self.dr.get_text('css->div.ivu-modal-confirm-body')

    def move_elment(self):
        '''拖动赔率条'''
        self.dr.drag_and_drop('css->div.el-slider__button.el-tooltip', 'css->div#lt_sel_insert.g_submit')
