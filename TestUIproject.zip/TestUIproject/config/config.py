# -*- coding:utf-8 -*-
'''
时间：2017-12-18
作者：Jin
说明：配置文件
'''
# 项目参数设置
project_path = "F:/TestUIproject/"
# 日志路径
log_path = project_path + "logs/"
# 截图文件路径
img_path = project_path + "tmp/img/"
# 测试报告路径
report_path = project_path + "report/"
# 测试数据路径
data_path = project_path + "data/"
# 测试用例路径
cass_path = project_path + "testcass/"
# 默认浏览器chrome phantomjs
browser = 'chrome'
# 登陆地址
login_url = 'http://lot.hpwbt666.com/apis'
# 测试购彩大厅地址
bettingHall_url = 'http://lot.hpwbt666.com/bettingHall/home'
# 用户账号
username = 'test2008'
